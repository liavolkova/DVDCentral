﻿using LV.DVDCentral.BL.Models;

namespace LV.DVDCentral.UI.ViewModels
{
    public class CustomerOrdersVM
    {
        public Customer Customer { get; set; }
        public User User { get; set; }
        public List<Customer> Customers { get; set; }
    }
}
