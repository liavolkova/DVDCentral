﻿using LV.DVDCentral.BL.Models;

namespace LV.DVDCentral.UI.ViewModels
{
    public class CustomerVM
    {
        public int CustomerId { get; set; }
        public List<Customer> Customers { get; set; }
        public int UserId { get; set; }
        public ShoppingCart Cart { get; set; }

    }
}
