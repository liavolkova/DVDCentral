﻿using LV.DVDCentral.BL;
using LV.DVDCentral.BL.Models;
using Microsoft.AspNetCore.Mvc;

namespace LV.DVDCentral.UI.Controllers
{
    public class OrderItemController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Title = "List of Order Items";
            return View(OrderItemManager.Load());
        }
        
    }
}