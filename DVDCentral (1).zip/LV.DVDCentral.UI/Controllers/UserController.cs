﻿using LV.DVDCentral.BL.Models;
using Microsoft.AspNetCore.Mvc;
using LV.DVDCentral.UI.Extensions;
using Microsoft.AspNetCore.Identity;
using LV.DVDCentral.BL;

namespace BDF.ProgDec.UI.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Title = "List of Users";
            return View(UserManager.Load());
        }

        public IActionResult Create()
        {
            ViewBag.Title = "Create a User";
            return View();
        }
        [HttpPost]
        public IActionResult Create(User user)
        {
            try
            {
                int result = UserManager.Insert(user);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.Title = "Create a User";
                ViewBag.Error = ex.Message;
                throw;
            }
        }

        public IActionResult Edit(int id)
        {
            var item = UserManager.LoadById(id);
            ViewBag.Title = "Edit" + item.FullName;
            return View(item);
        }

        [HttpPost]
        public IActionResult Edit(int id, User user, bool rollback = false)
        {
            try
            {
                int result = UserManager.Update(user, rollback);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.Title = "Edit " + user.FullName;
                ViewBag.Error = ex.Message;
                return View(user);
            }
        }
        private void SetUser(User user)
        {

            HttpContext.Session.SetObject("user", user);

            if (user != null)
            {
                HttpContext.Session.SetObject("fullname", "Welcome " + user.FullName);
            }
            else
            {
                HttpContext.Session.SetObject("fullname", string.Empty);
            }
        }


        public IActionResult Logout()
        {
            ViewBag.Title = "Logout";
            SetUser(null);
            return View();
        }

        public IActionResult Seed()
        {
            UserManager.Seed();
            return View();
        }

        public IActionResult Login(string returnUrl)
        {

            TempData["returnUrl"] = returnUrl;
            ViewBag.Title = "Login";
            return View();
        }

        [HttpPost]
        public IActionResult Login(User user)
        {
            try
            {
                if (UserManager.Login(user))
                {
                    SetUser(user);

                    if (TempData["returnUrl"] != null)
                        return Redirect(TempData["returnUrl"]?.ToString());
                    else
                        ViewBag.Message = "You are now logged in";
                }
                return View(user);
            }
            catch (Exception ex)
            {
                ViewBag.Title = "Login";
                ViewBag.Error = ex.Message;
                return View(user);
            }
        }
    }
}
