﻿using LV.DVDCentral.BL.Models;
using LV.DVDCentral.BL;
using LV.DVDCentral.UI.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;
using Microsoft.AspNetCore.Http.Extensions;
using LV.DVDCentral.UI.ViewModels;

namespace LV.ProgDec.UI.Controllers
{
    public class ShoppingCartController : Controller
    {
        ShoppingCart cart;
        // GET: ShoppingCartController
        public IActionResult Index()
        {
            ViewBag.Title = "Shopping Cart";
            cart = GetShoppingCart();

            return View(cart);
        }

        private ShoppingCart GetShoppingCart()
        {
            if (HttpContext.Session.GetObject<ShoppingCart>("cart") != null)
            {
                return HttpContext.Session.GetObject<ShoppingCart>("cart");
            }
            else
            {
                return new ShoppingCart();
            }
        }

        public IActionResult Remove(int id)
        {
            cart = GetShoppingCart();
            Movie movie = cart.Items.FirstOrDefault(i => i.Id == id);
            ShoppingCartManager.Remove(cart, movie);
            HttpContext.Session.SetObject("cart", cart);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Add(int id)
        {
            cart = GetShoppingCart();
            Movie movie = MovieManager.LoadById(id);
            ShoppingCartManager.Add(cart, movie);
            HttpContext.Session.SetObject("cart", cart);
            return RedirectToAction(nameof(Index), "Movie");
        }

        public IActionResult Checkout()
        {
            User user = new User();
            if (HttpContext.Session.GetObject<User>("user") == null)
            {
                return RedirectToAction("Login", "User", new { returnUrl = UriHelper.GetDisplayUrl(HttpContext.Request) });
            }
            else
            {
                return RedirectToAction("AssignToCustomer");


            }
        }
    
        private double CalculateTotalCost(ShoppingCart cart)
        {
            // Calculate the total cost based on the items in the cart
            double totalCost = 0.0;
            foreach (Movie item in cart.Items)
            {
                totalCost += item.Cost;
            }
            return totalCost;
        }
        public ActionResult AssignToCustomer()
        {
            User user = HttpContext.Session.GetObject<User>("user");
            Customer customer = new Customer();
            CustomerVM customerVM = new CustomerVM();
            customerVM.Cart = GetShoppingCart();
            customerVM.Customers = new List<Customer>();
            customerVM.Customers = CustomerManager.Load();
            customerVM.UserId = user.Id;

            if (customerVM.Customers.Where(c => c.UserId == user.Id).FirstOrDefault() != null)
            {
                customerVM.CustomerId = customerVM.Customers.Where(c => c.UserId == user.Id).FirstOrDefault().Id;

            }

            HttpContext.Session.SetObject("customerVM", customerVM);

            ViewData["ReturnUrl"] = UriHelper.GetDisplayUrl(HttpContext.Request);
            return View(customerVM);

        }

        [HttpPost]
        public ActionResult AssignToCustomer(CustomerVM customerVM)
        {
            try
            {
                customerVM.Cart = GetShoppingCart();
                ShoppingCartManager.Checkout(customerVM.Cart);
                HttpContext.Session.SetObject("cart", null);
                cart = null;


                return View("Checkout");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
