﻿using LV.DVDCentral.BL;
using LV.DVDCentral.BL.Models;
using LV.DVDCentral.UI.Models;
using LV.DVDCentral.UI.ViewModels;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;

namespace LV.DVDCentral.UI.Controllers
{
    
    public class CustomerController : Controller
    {
        List<Customer> customers;
        public IActionResult Index()
        {
            if (Authenticate.IsAuthenticated(HttpContext))
            {
                return View(CustomerManager.Load());
            }
            else
                return RedirectToAction("Login", "User", new { returnUrl = UriHelper.GetDisplayUrl(HttpContext.Request) });

        }

        public IActionResult Details(int id)
        {
            if (Authenticate.IsAuthenticated(HttpContext))
            {
                Customer customer = CustomerManager.LoadById(id);
                return View(customer);
            }
            else
                return RedirectToAction("Login", "User", new { returnUrl = UriHelper.GetDisplayUrl(HttpContext.Request) });
        }

        public IActionResult Create()
        {
            ViewBag.Title = "Create an Order";
            if (Authenticate.IsAuthenticated(HttpContext))
            {
                ViewBag.Title = "Create";
                Customer customer = new Customer();
                //customer.users = UserManager.Load();
                return View(customer);
            }
                
            else
                return RedirectToAction("Login", "User", new { returnUrl = UriHelper.GetDisplayUrl(HttpContext.Request) });
        }

        [HttpPost]
        public IActionResult Create(Customer customer)
        {
            try
            {
                ViewBag.Title = "Create a new customer";
                int result = CustomerManager.Insert(customer);
                return RedirectToAction("AssignToCustomer", "ShoppingCart");
            }
            catch (Exception)
            {

                throw;
            }
        }

        public IActionResult Edit(int id)
        {
            var item = CustomerManager.LoadById(id);
            ViewBag.Title = "Edit " + item.FirstName + " " + item.LastName;
            return View(item);
        }

        [HttpPost]
        public IActionResult Edit(int id, Customer customer, bool rollback = false)
        {
            try
            {
                int result = CustomerManager.Update(customer, rollback);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(customer);
            }
        }

        public IActionResult Delete(int id)
        {
            return View(CustomerManager.LoadById(id));
        }

        [HttpPost]
        public IActionResult Delete(int id, Customer customer, bool rollback = false)
        {
            try
            {
                int result = CustomerManager.Delete(id, rollback);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(customer);
            }
        }
    }
}