﻿using LV.DVDCentral.BL;
using LV.DVDCentral.BL.Models;
using LV.DVDCentral.UI.Extensions;
using LV.DVDCentral.UI.Models;
using LV.DVDCentral.UI.ViewModels;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.Web.CodeGeneration.Design;

namespace LV.DVDCentral.UI.Controllers
{
    public class MovieController : Controller
    {
        private readonly IWebHostEnvironment _host;

        public MovieController(IWebHostEnvironment host)
        {
            _host = host;
        }

        public IActionResult Index()
        {
            ViewBag.Title = "List of All Movies";
            return View("IndexCard", MovieManager.Load());
        }
        [HttpGet]
        public ActionResult Load(int Id)
        {
            var movies = MovieManager.Load(Id);
            return View("Index", movies);
        }
        public IActionResult Details(int id)
        {
            var item = MovieManager.LoadById(id);
            ViewBag.Title = "Details for " + item.Title;
            return View(item);
        }

        public IActionResult Create()
        {

            ViewBag.Title = "Create a Movie";

            if (Authenticate.IsAuthenticated(HttpContext))
            {
                ViewBag.Title = "Create";
                MovieVM movieVM = new MovieVM();

                //movieVM.Movie = new BL.Models.Movie();
                movieVM.Genres = GenreManager.Load();
                movieVM.Directors = DirectorManager.Load();
                movieVM.Ratings = RatingManager.Load();
                movieVM.Formats = FormatManager.Load();
                HttpContext.Session.SetObject("movieVM", movieVM);
                
             
                return View(movieVM);
            }
               
            else
                return RedirectToAction("Login", "User", new { returnUrl = UriHelper.GetDisplayUrl(HttpContext.Request) });

        }
        [HttpPost]
        public IActionResult Create(MovieVM movieVM)
        {
            try
            {
                if (movieVM.File != null)
                {
                    movieVM.Movie.ImagePath = movieVM.File.FileName;
                    string path = _host.WebRootPath + "\\images\\";
                    using (var stream = System.IO.File.Create(path + movieVM.File.FileName))
                    {
                        movieVM.File.CopyTo(stream);
                        ViewBag.Message = "File Uploaded Successfully...";
                    }
                }

                IEnumerable<int> newGenreIds = new List<int>();
                if (movieVM.GenreIds != null)
                    newGenreIds = movieVM.GenreIds;
                IEnumerable<int> adds = newGenreIds;
           

                int result = MovieManager.Insert(movieVM.Movie);


                movieVM.GenreIds.ToList().ForEach(genreId => MovieGenreManager.Insert(movieVM.Movie.Id, genreId));
              
               return RedirectToAction(nameof(Index));
            }
            catch (Exception)
            {

                throw;
            }
        }
        public IActionResult Browse(int id) 
        {
            return View(nameof(Index), MovieManager.Load(id));
        }

        public IActionResult BrowseAll()
        {
            ViewBag.Title = "All Movies";
            return View(nameof(Index), MovieManager.Load());
        }
        public IActionResult Edit(int id)
        {

            if (Authenticate.IsAuthenticated(HttpContext))
            {

                MovieVM movieVM = new MovieVM();

                movieVM.Movie = MovieManager.LoadById(id);
                movieVM.Directors = DirectorManager.Load();
                movieVM.Ratings = RatingManager.Load();
                movieVM.Formats = FormatManager.Load();
                movieVM.Genres = GenreManager.Load();

                movieVM.GenreIds = movieVM.Movie.GenreList.Select(a => a.Id).ToList();
                HttpContext.Session.SetObject("genreids", movieVM.GenreIds);

                ViewBag.Title = "Edit " + movieVM.Movie.Title;
                return View(movieVM);
            }
                
            else
                return RedirectToAction("Login", "User", new { returnUrl = UriHelper.GetDisplayUrl(HttpContext.Request) });
        }
        [HttpPost]
        public IActionResult Edit(int id, MovieVM movieVM, bool rollback = false)
        {
            try
            {
                if (movieVM.File != null)
                {
                    movieVM.Movie.ImagePath = movieVM.File.FileName;
                    string path = _host.WebRootPath + "\\images\\";
                    using (var stream = System.IO.File.Create(path + movieVM.File.FileName))
                    {
                        movieVM.File.CopyTo(stream);
                        ViewBag.Message = "File Uploaded Successfully...";
                    }
                }

                IEnumerable<int> newGenreIds = new List<int>();
                if (movieVM.GenreIds != null)
                    newGenreIds = movieVM.GenreIds;

                IEnumerable<int> oldGenreIds = new List<int>();
                oldGenreIds = GetObject();

                

                IEnumerable<int> deletes = oldGenreIds.Except(newGenreIds);
                IEnumerable<int> adds = newGenreIds.Except(oldGenreIds);

                deletes.ToList().ForEach(d => MovieGenreManager.Delete(id,d));
                adds.ToList().ForEach(a => MovieGenreManager.Insert(id,a));

                int result = MovieManager.Update(movieVM.Movie, rollback);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(movieVM);
            }
        }
        private IEnumerable<int> GetObject()
        {
            if (HttpContext.Session.GetObject<IEnumerable<int>>("genreids") != null)
            {
                return HttpContext.Session.GetObject<IEnumerable<int>>("genreids");
            }
            else
            {
                return null;
            }
        }
        public IActionResult Delete(int id)
        {
            var item = MovieManager.LoadById(id);
            ViewBag.Title = "Delete";
            return View(item);
        }

    }


}