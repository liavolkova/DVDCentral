﻿using LV.DVDCentral.BL.Models;
using LV.DVDCentral.UI.Extensions;

namespace LV.DVDCentral.UI.Models
{
    public static class Authenticate
    {
        public static bool IsAuthenticated(HttpContext context)
        {
            if (context.Session.GetObject<User>("user") != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
