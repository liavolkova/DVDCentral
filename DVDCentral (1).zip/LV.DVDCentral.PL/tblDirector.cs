﻿using System;
using System.Collections.Generic;

namespace LV.DVDCentral.PL;

public partial class tblDirector
{
    public int Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;
}
