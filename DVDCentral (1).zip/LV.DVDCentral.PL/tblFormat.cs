﻿using System;
using System.Collections.Generic;

namespace LV.DVDCentral.PL;

public partial class tblFormat
{
    public int Id { get; set; }

    public string Description { get; set; } = null!;
}
