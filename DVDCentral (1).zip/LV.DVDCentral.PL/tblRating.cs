﻿using System;
using System.Collections.Generic;

namespace LV.DVDCentral.PL;

public partial class tblRating
{
    public int Id { get; set; }

    public string Description { get; set; } = null!;
}
