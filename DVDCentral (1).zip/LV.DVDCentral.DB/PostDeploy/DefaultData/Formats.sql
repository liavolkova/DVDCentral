﻿BEGIN
	INSERT INTO tblFormat (Id, Description)
	VALUES
	(1, 'DVD'), 
	(2, 'Blu-ray'),
	(3, 'VHS')
END