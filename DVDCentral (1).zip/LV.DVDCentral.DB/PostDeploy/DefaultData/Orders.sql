﻿BEGIN 
	INSERT INTO	tblOrder (Id, CustomerId, OrderDate, UserId, ShipDate)
	VALUES 
	(1, 1, 2012-12-23, 3, 2012-12-24),
	(2, 2, 2021-05-12, 2, 2021-05-13),
	(3, 3, 2020-06-06, 1, 2020-06-07)
END