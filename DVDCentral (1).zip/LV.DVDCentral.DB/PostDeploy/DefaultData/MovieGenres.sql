﻿BEGIN 
	INSERT INTO	tblMovieGenre (Id, MovieId, GenreId)
	VALUES 
	(1, 2, 3),
	(2, 3, 1), 
	(3, 1, 2)
END