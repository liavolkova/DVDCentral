﻿BEGIN 
	INSERT INTO tblCustomer (Id, FirstName, LastName, UserId, Address, City, State, ZIP, Phone)
	VALUES 
	(1, 'Jack', 'Jones', 3, '101 Main St', 'Appleton', 'WI', 54914, 8498490384),
	(2, 'Lisa', 'Trembell', 2, '134 Calumet St', 'Appleton', 'WI', 54913, 9309291356),
	(3, 'Sam', 'Smith', 1, '101 Northland Ave', 'Menasha', 'WI', 54952, 9203347766)
END