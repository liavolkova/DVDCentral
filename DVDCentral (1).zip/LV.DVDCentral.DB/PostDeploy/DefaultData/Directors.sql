﻿BEGIN 
	INSERT INTO tblDirector (Id, FirstName, LastName)
	VALUES 
	(1, 'Chris', 'Columbus'),
	(2, 'Johnathan', 'Levine'),
	(3, 'John Lee', 'Hancock')
END