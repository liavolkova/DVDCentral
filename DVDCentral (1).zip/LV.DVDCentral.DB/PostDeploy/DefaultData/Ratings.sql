﻿BEGIN
	INSERT INTO tblRating (Id, Description) 
	VALUES 
	(1, 'PG'),
	(2, 'R'),
	(3, 'G ')
END