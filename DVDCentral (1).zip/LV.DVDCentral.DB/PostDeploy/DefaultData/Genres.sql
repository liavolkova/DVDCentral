﻿BEGIN 
	INSERT INTO tblGenre (Id, Description)
	VALUES 
	(1, 'Comedy'),
	(2, 'Drama'),
	(3, 'Children Movies')
END