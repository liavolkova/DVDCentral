﻿BEGIN
	INSERT INTO tblUser (Id, FirstName, LastName, UserId, Password)
	VALUES 
	(1, 'Javier', 'Hernandez', 'javier11', 'root'),
	(2, 'Maria', 'Kirkman', 'mariamaria', 'lemonade'),
	(3, 'Lisa', 'Trembell', 'lisatrembell', 'ilovemovies')
END