﻿BEGIN 
	INSERT INTO tblOrderItem (Id, OrderId, Quantity, MovieId, Cost)
	VALUES 
	(1, 3, 4, 1, 19),
	(2, 2, 3, 2, 15),
	(3, 1, 2, 3, 13)
END