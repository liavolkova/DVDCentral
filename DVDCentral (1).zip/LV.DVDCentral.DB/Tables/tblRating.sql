﻿CREATE TABLE [dbo].[tblRating]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Description] VARCHAR(50) NOT NULL
)
