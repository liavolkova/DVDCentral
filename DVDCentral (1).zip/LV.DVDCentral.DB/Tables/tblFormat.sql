﻿CREATE TABLE [dbo].[tblFormat]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Description] VARCHAR(50) NOT NULL
)
