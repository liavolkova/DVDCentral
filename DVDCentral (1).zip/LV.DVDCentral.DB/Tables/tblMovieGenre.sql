﻿CREATE TABLE [dbo].[tblMovieGenre]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [MovieId] INT NOT NULL, 
    [GenreId] INT NOT NULL
)
