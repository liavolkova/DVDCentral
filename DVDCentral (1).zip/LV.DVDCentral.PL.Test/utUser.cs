﻿using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LV.DVDCentral.PL.Test
{
    [TestClass]
    public class utUser
    {

        protected DVDCentralEntities dc;
        protected IDbContextTransaction transaction;

        [TestInitialize]
        public void Initialize()
        {
            dc = new DVDCentralEntities();
            transaction = dc.Database.BeginTransaction();
        }

        [TestCleanup]
        public void Cleanup()
        {
            transaction.Rollback();
            transaction.Dispose();
            dc = null;
        }


        [TestMethod]
        public void LoadTest()
        {
            DVDCentralEntities dc = new DVDCentralEntities();
            Assert.AreEqual(3, dc.tblUsers.Count());
        }

        [TestMethod]
        public void InsertTest()
        {
            tblUser entity = new tblUser();
            entity.Id = -5;
            entity.FirstName = "Jack";
            entity.LastName = "Michaels";
            entity.UserId = "jmichaels";
            entity.Password = "password";

            dc.tblUsers.Add(entity);

            int result = dc.SaveChanges();
            Assert.AreEqual(1, result);
        }

        [TestMethod]

        public void UpdateTest()
        {
            tblUser entity = dc.tblUsers.FirstOrDefault();

            entity.FirstName = "Jack";
            entity.LastName = "Michaels";
            entity.UserId = "jmichaels";
            entity.Password = "password";

            int result = dc.SaveChanges();
            Assert.IsTrue(result > 0);
        }
        [TestMethod]
        public void DeleteTest()
        {
            tblUser entity = dc.tblUsers.Where(e => e.Id == 2).FirstOrDefault();

            dc.tblUsers.Remove(entity);
            int result = dc.SaveChanges();

            Assert.AreNotEqual(result, 0);

        }
        [TestMethod]
        public void LoadByIdTest()
        {
            tblUser entity = dc.tblUsers.Where(e => e.Id == 2).FirstOrDefault();
            Assert.AreEqual(entity.Id, 2);

        }
    }
}
