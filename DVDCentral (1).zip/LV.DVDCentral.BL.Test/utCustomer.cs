using LV.DVDCentral.BL.Models;

namespace LV.DVDCentral.BL.Test
{
    [TestClass]
    public class utCustomer
    {
        [TestMethod]
        public void LoadTest()
        {
            Assert.AreEqual(3, CustomerManager.Load().Count);
        }

        [TestMethod]
        public void InsertTest()
        {
            int id = 0;
            int results = CustomerManager.Insert("John", "Hamilton", 3, "586 Lucerne Dr", "Menasha", "WI", "54923", "9178914372", ref id, true);
            Assert.AreEqual(4, id);
            Assert.AreEqual(1, results);
        }

        [TestMethod]
        public void UpdateTest()
        {
            Customer customer = CustomerManager.LoadById(3);
            customer.FirstName = "John";
            customer.LastName = "Hamilton";
            customer.UserId = 3;
            customer.Address = "586 Lucerne Dr";
            customer.City = "Appleton";
            customer.State = "WI";
            customer.ZIP = "54924";
            customer.Phone = "9178914372";
            int results = CustomerManager.Update(customer, true);
            Assert.AreEqual(1, results);
        }

        [TestMethod]
        public void DeleteTest()
        {
            int results = CustomerManager.Delete(3, true);
            Assert.AreEqual(1, results);
        }
    }
}