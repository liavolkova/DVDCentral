using LV.DVDCentral.BL.Models;

namespace LV.DVDCentral.BL.Test
{
    [TestClass]
    public class utOrderItem
    {
        [TestMethod]
        public void LoadTest()
        {
            Assert.AreEqual(3, OrderItemManager.Load().Count);
        }

        [TestMethod] 
        public void LoadByOrderIdTest() 
        {
            int orderId = OrderItemManager.Load().FirstOrDefault().OrderId;
            Assert.IsTrue(OrderItemManager.LoadByOrderId(orderId).Count >0);
        }

        [TestMethod]
        public void InsertTest()
        {
            int id = 0;
            int results = OrderItemManager.Insert(1, 2, 2, 5,  ref id, true);
            Assert.AreEqual(4, id);
            Assert.AreEqual(1, results);
        }

        [TestMethod]
        public void UpdateTest()
        {
            OrderItem orderItem = OrderItemManager.LoadById(3);
            orderItem.OrderId = 1;
            orderItem.Quantity = 2;
            orderItem.MovieId = 2;
            orderItem.Cost = 15;
            int results = OrderItemManager.Update(orderItem, true);
            Assert.AreEqual(1, results);
        }

        [TestMethod]
        public void DeleteTest()
        {
            int results = OrderItemManager.Delete(3, true);
            Assert.AreEqual(1, results);
        }
    }
}