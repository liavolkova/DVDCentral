using LV.DVDCentral.BL.Models;

namespace LV.DVDCentral.BL.Test
{
    [TestClass]
    public class utMovie
    {
        [TestMethod]
        public void LoadTest()
        {
            Assert.AreEqual(3, MovieManager.Load().Count);
        }

        [TestMethod]
        public void InsertTest()
        {
            int id = 0;
            int results = MovieManager.Insert("Test","Test", 3, 2, 1, 5, 10, "test.jpg",  ref id, true);
            Assert.AreEqual(4, id);
            Assert.AreEqual(1, results);
        }

        [TestMethod]
        public void InsertTest2()
        {
            int id = 0;
            Movie movie = new Movie
            {
            Title = "Test",
            Description = "test",
            DirectorId = 3,
            RatingId = 2,
            Cost = 1,
            InStkQty = 10,
            ImagePath = "test.jpg"
        };

            int results = MovieManager.Insert(movie, true);
            Assert.AreEqual(1, results);
        }


        [TestMethod]
        public void UpdateTest()
        {
            Movie movie = MovieManager.LoadById(3);
            movie.Title = "Test";
            movie.Description = "test";
            movie.DirectorId = 3;
            movie.RatingId = 2;
            movie.Cost = 1;
            movie.InStkQty = 10;
            movie.ImagePath = "test.jpg";
            int results = MovieManager.Update(movie, true);
            Assert.AreEqual(1, results);
        }

        [TestMethod]
        public void DeleteTest()
        {
            int results = MovieManager.Delete(3, true);
            Assert.AreEqual(1, results);
        }
    }
}