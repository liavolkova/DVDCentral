using LV.DVDCentral.BL.Models;

namespace LV.DVDCentral.BL.Test
{
    [TestClass]
    public class utMovieGenre
    {

        [TestMethod]
        public void InsertTest()
        {
            int id = 0;
            int movieId = MovieGenreManager.Insert(1,2,  true);
            Assert.AreEqual(0,id);
        }

        [TestMethod]
        public void UpdateTest()
        {
            int results = MovieGenreManager.Update(1,2, true);
            Assert.AreEqual(0, results);
        }

        [TestMethod]
        public void DeleteTest()
        {
            int results = MovieGenreManager.Delete(1,2, true);
            Assert.AreEqual(1, results);
        }
    }
}