using LV.DVDCentral.BL.Models;
using static LV.DVDCentral.BL.UserManager;

namespace LV.DVDCentral.BL.Test
{
    [TestClass]
    public class utUser
    {
        [TestMethod]
        public void LoadTest()
        {
            Assert.AreEqual(0, UserManager.Load().Count);
        }

        [TestMethod]
        public void InsertTest()
        {
            //int id = 0;
            //int results = UserManager.Insert("Test","Test", "username", "password",  ref id, true);
            //Assert.AreEqual(4, id);
            //Assert.AreEqual(1, results);
        }

        [TestMethod]
        public void UpdateTest()
        {
            User user = UserManager.LoadById(3);
            user.FirstName = "";
            user.LastName = "";
            user.UserId = "";
            user.Password = "";
            int results = UserManager.Update(user, true);
            Assert.AreEqual(1, results);
        }

        [TestMethod]
        public void DeleteTest()
        {
            int results = UserManager.DeleteAll();
            Assert.AreEqual(0, results);
        }
        [TestMethod]
        public void LoginSucessfulTest()
        {
            Seed();
            Assert.IsTrue(UserManager.Login(new User { UserId = "bfoote", Password = "maple" }));
            Assert.IsTrue(UserManager.Login(new User { UserId = "lvolkova", Password = "testtest" }));
        }

        public void Seed()
        {
            UserManager.Seed();
        }

        
        [TestMethod]
        public void LoginFailureNoUserId()
        {
            try
            {
                Seed();
                Assert.IsFalse(UserManager.Login(new User { UserId = "", Password = "maple" }));
            }
            catch (LoginFailureException)
            {
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void LoginFailureBadPassword()
        {
            try
            {
                Seed();
                Assert.IsFalse(UserManager.Login(new User { UserId = "bfoote", Password = "birch" }));
            }
            catch (LoginFailureException)
            {
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void LoginFailureBadUserId()
        {
            try
            {
                Seed();
                Assert.IsFalse(UserManager.Login(new User { UserId = "bfote", Password = "maple" }));
            }
            catch (LoginFailureException)
            {
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod]
        public void LoginFailureNoPassword()
        {
            try
            {
                Seed();
                Assert.IsFalse(UserManager.Login(new User { UserId = "bfoote", Password = "" }));
            }
            catch (LoginFailureException)
            {
                Assert.IsTrue(true);
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
    }
}